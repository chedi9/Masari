# Tunisia Mobility Platform

**Status: DISCOVERY IN PROGRESS.** This is the local working folder. Full application implementation remains behind the Phase 0 feasibility gate.

## Core files
- `SDD_Tunisia_Mobility_Platform.md` — single current SDD v0.5 and owner-approved direction.
- `Tunisia_Mobility_Decision_Register.md` — confirmed choices, adopted defaults and evidence/legal TBDs.
- `dashboard.html` — local dashboard; open directly or use `start_todo_board.bat`.
- `docs/MASTER_ROADMAP.md` and `docs/AI_HANDOFF_LOG.md` — project plan and handoffs.
- `docs/research/TUM-P0-002_CANDIDATE_AREA_READINESS.md` — preliminary evidence review for the four rollout areas and the five named transport apps/services.
- `AGENTS.md` and `CLAUDE.md` — working rules.

Discovery remains in progress. Recommended product defaults authorized by the owner are recorded; evidence-dependent, legal and numeric validation items remain TBD. Passenger-report classification is confirmed as feature-based Option C, including guest access for critical safety reporting. A preliminary desk review of candidate datasets and Thnity, Wassalni, RNTT, Winicari and Tunismapper is complete; no rollout area is certified ready. The next task is TUM-P0-003: inspect the actual public dataset files. Dashboard checklist marks reset on reload.
