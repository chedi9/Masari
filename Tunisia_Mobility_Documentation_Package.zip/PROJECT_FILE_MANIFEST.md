# Project File Manifest

| File | Role |
|---|---|
| `AGENTS.md`, `CLAUDE.md` | Agent operating instructions |
| `SDD_Tunisia_Mobility_Platform.md` | Single active consolidated SDD v0.5 |
| `Tunisia_Mobility_Decision_Register.md` | Current decisions, adopted recommended defaults and evidence/legal TBDs |
| `dashboard.html` | Local project dashboard |
| `start_todo_board.bat` | Opens the local dashboard |
| `README_START_HERE.md` | Workspace orientation |
| `docs/MASTER_ROADMAP.md` | Single project roadmap |
| `docs/AI_HANDOFF_LOG.md` | Append-only work history |
| `docs/OWNER_TODO.md` | Owner checklist |
| `docs/research/TUM-P0-002_CANDIDATE_AREA_READINESS.md` | Preliminary sourced desk review; area readiness remains unverified |
| `docs/adr/`, `docs/research/`, `docs/templates/` | Core decision, evidence and handoff templates |
| `docs/archive/` | Superseded source snapshots and package artifacts; not active baselines |
| `docs/archive/reference/` | Preserved v0.3 reference set |
| `FILE_INVENTORY.txt` | Local file listing; excludes `.git` |
