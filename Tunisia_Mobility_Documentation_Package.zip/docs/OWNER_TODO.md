# Owner TODO

- [x] Review the consolidated SDD v0.5 and current decision register.
- [x] Resolve passenger-report classification using recommended Option C, including guest access for critical safety reports.
- [x] Complete the preliminary desk review `TUM-P0-002`; it does not certify any area as launch-ready.
- [ ] Execute `TUM-P0-003`: inspect actual public candidate data files for schema, dates, coverage, license metadata and quality.
- [ ] Complete the Phase 0 feasibility evidence and owner gate review before full application implementation.
- [x] Push the reviewed local project documentation updates after the owner's explicit authorization.
