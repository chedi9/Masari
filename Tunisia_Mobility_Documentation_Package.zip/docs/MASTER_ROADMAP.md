# Tunisia Mobility Platform — Master Roadmap

**Roadmap version:** 0.3 working status snapshot
**Product baseline:** Consolidated SDD v0.5 and Decision Register v0.5
**Date:** 3 November 2026
**Owner:** Human product owner  
**Cost rule:** Zero spend unless explicitly changed by the owner.

> Discovery remains in progress. This is the sole execution roadmap. `SDD_Tunisia_Mobility_Platform.md` is the single active SDD; superseded source copies are archived under `docs/archive/`.

## Current project state

- **Current phase:** Phase 0 — discovery and feasibility.
- **Status marker:** **DISCOVERY IN PROGRESS**.
- **Implementation gate:** Full application implementation is not authorized until Phase 0 exit criteria are met or the owner explicitly revises the gate.
- **D-06 passenger report classification:** Confirmed by owner direction — feature-based Option C. The v0.3 journey-preference D-06 remains separately recorded pending canonical ID assignment.
- **Workspace status:** One active SDD and one current register are present; dashboard and static-file launcher are retained. Legacy reference copies are archived under `docs/archive/reference/`. Dashboard checklist is in-memory only.
- **Current next TODO:** `TUM-P0-003 — Download and profile the public candidate transport datasets for Greater Tunis, Sousse, Monastir and Sfax; record schemas, counts, service dates, geography, license metadata and quality gaps in a reproducible inventory.`
- **Owner of next action:** Data researcher / repository maintainer.
- **Tools:** Public transport catalog downloads, PowerShell and local inspection; no paid services, credentials or account creation.
- **Dependencies:** Completed desk evidence review TUM-P0-002; confirmed rollout areas and service-area coverage rule; current SDD/register.
- **Acceptance:** A reproducible inventory records candidate resource URLs, file checksums, formats, schema, record counts, service dates, geographic extent, license metadata and observed quality gaps. Stop on unclear terms or credential/cost requirements.

## Current next task

| Task ID | Task | Priority | Status | Owner | Dependencies | Deliverable / acceptance and validation evidence |
|---|---|---:|---|---|---|---|
| TUM-P0-001 | Reconcile source of truth | P0 | DONE | Codex | Owner decisions and recommended defaults supplied | Current SDD/register reconciled locally; source snapshots preserved; D-06 collision documented. Evidence: local SDD/register review and status search. |
| TUM-P0-001a | Consolidate local workspace and dashboard | P1 | DONE | Codex | Local folder audit | One active SDD, current register, updated dashboard and core-file layout. Evidence: root listing and inventory. |
| TUM-P0-001b | Apply owner-directed recommendation defaults | P0 | DONE | Codex | Latest explicit owner instruction | D-06 C and practical UX/transport defaults recorded; evidence/legal TBDs retained; dashboard aligned. Evidence: content checks; no app tests requested. |
| TUM-P0-002 | Candidate-area readiness evidence review | P0 | DONE | Codex | Confirmed rollout areas; SDD/register | Desk review compared Greater Tunis, Sousse, Monastir and Sfax; assessed Thnity, Wassalni, RNTT, Winicari and Tunismapper as leads; recorded limitations and proposed non-approved measures. Evidence: `docs/research/TUM-P0-002_CANDIDATE_AREA_READINESS.md`; official catalog and service pages linked there. This does not certify city readiness. |

## Phase 0 work still required

| Task ID | Task | Priority | Status | Owner | Dependencies | Deliverable / acceptance and evidence |
|---|---|---:|---|---|---|---|
| TUM-P0-002 | Candidate-area readiness evidence review | P0 | DONE | Codex | Confirmed rollout areas; SDD/register | Preliminary sourced desk audit for all four areas; gaps, app leads and proposed metrics recorded. Does not establish readiness. Evidence: `docs/research/TUM-P0-002_CANDIDATE_AREA_READINESS.md`. |
| TUM-P0-003 | Transport dataset inventory | P0 | READY | Data researcher | P0-002 | Download and profile public candidate files; inventory schemas, counts, geography, service dates, license metadata and quality gaps. No app implementation. |
| TUM-P0-004 | Data licensing and reuse audit | P0 | BACKLOG | Data/legal researcher | P0-003 | Evidence of allowed use for each proposed source before integration. Not started. |
| TUM-P0-005 | Map/geocoding/routing comparison | P0 | BACKLOG | Mapping researcher | P0-002; P0-004 | Tunisia coverage, Arabic/French search, routing, offline terms and cost comparison. Not started. |
| TUM-P0-006 | UX validation and Pro offline detail pack | P1 | BACKLOG | Product/UX designer | P0-001b; P0-005 | Validate adopted UX defaults; define offline feature/entitlement details. Not started. |
| TUM-P0-007 | Transport operations research | P1 | BACKLOG | Transport-data researcher | P0-003 | Validate route branches/diversions and rural/taxi evidence handling. Not started. |
| TUM-P0-008 | Privacy/security review plan | P0 | BACKLOG | Privacy/security reviewer | P0-001b | Assessment plan; no retention periods before qualified review. Not started. |
| TUM-P0-009 | Approved-stack architecture pack | P0 | BACKLOG | Software architect | P0-003; P0-005 | ADRs for confirmed baseline plus provider/interface validation. Not started. |
| TUM-P0-010 | Data/routing feasibility prototype | P0 | BACKLOG | Data/engineering contributor | P0-002–005; P0-009 | Reproducible import and verified pilot journey using real, permitted data. Not started. |
| TUM-P0-011 | Pro offline product/technical definition | P1 | BACKLOG | Product/engineering contributor | P0-005; P0-009 | Package matrix, freshness, sync, storage, licensing and entitlements; prices/terms remain TBD. Not started. |
| TUM-P0-012 | Phase 0 gate review | P0 | BACKLOG | Product owner | P0-002–011 | Review evidence, unresolved items, pilot recommendation and owner approval before full build. Not started. |

## Known approval gates

- Evidence-dependent values and legal details remain TBD; do not replace them with guesses.
- No full-app implementation before Phase 0 gate approval.
- All data sources and map services require coverage, licensing and cost review.
- Privacy and Tunisian legal review precede persistent location collection; retention periods are not set.
- Recommendations and illustrative designs are not approvals.

## Update log

| Date | Agent/tool | Task | Summary | Evidence |
|---|---|---|---|---|
| 2026-11-03 | Codex | PACKAGE-001 | Inspected repository and prepared a working documentation package with current decision reconciliation. No GitHub files changed. | Source commit `b40d641fc9285a992974fb57258a8bd06ad1403b`; current register/addendum in this package. |
| 2026-11-03 | Codex | TUM-P0-001b | Applied owner-authorized recommendations/defaults; updated SDD/register/dashboard and prepared TUM-P0-002. | Local file inspection and content checks; no Git commands or app tests. |
| 2026-11-03 | Codex | TUM-P0-002 | Completed a preliminary desk review of candidate-area datasets and five named transport apps/services; documented evidence gaps and proposed, unapproved measurement definitions. | `docs/research/TUM-P0-002_CANDIDATE_AREA_READINESS.md`; linked official catalog/operator/app disclosures. |
| 2026-11-03 | Codex | TUM-P0-002-PUBLISH | Published the reviewed local project documentation and readiness note to `origin/main`. | Commit `c9f9264`; push completed successfully. |

## Current task state

- **Active task:** None; `TUM-P0-002` desk review is complete. City readiness remains unverified.
- **Current next TODO:** `TUM-P0-003` — download and profile public candidate datasets; record schema, counts, geography, service dates, license metadata and quality gaps.
- **Status:** DISCOVERY IN PROGRESS. A preliminary desk review is complete; full application implementation remains gated pending data inspection, field validation and owner gate review.



